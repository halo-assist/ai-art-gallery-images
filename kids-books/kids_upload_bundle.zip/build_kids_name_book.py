"""kdp-kids-books product generator: personalized children's name books.

Deterministic: any name 2-12 letters -> A4 interior PDF, seed derived from the
name (re-runs reproduce the same HTML exactly; PDF bytes differ only in PDF
metadata dates). Typography + geometric CSS/SVG art only, no raster images, so
PDFs stay small and print cleanly.

Pages: cover, belongs-to, grown-up note, letter banner, big trace, rainbow
write, letter count, letter hunt, name-in-the-stars, per-letter trace pages
(2/page), write-it-myself, 4 story pages, letter maze, certificate.

Usage:
  python3 build_kids_name_book.py                 # 3 default variants
  python3 build_kids_name_book.py Oliver [--out DIR]
"""
import hashlib
import html
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import FONTS, html_doc, render_pdf  # noqa: E402

OUT = "/Users/hainguyen/idea_lab/artifacts/kdp-kids-books/products"
os.makedirs(OUT, exist_ok=True)

F_INTER = f"file://{FONTS}/Inter.ttf"
F_CAVEAT = f"file://{FONTS}/Caveat.ttf"

# ---------- palette ----------
CORAL, MANGO, TEAL, SKY, GRAPE, BERRY = "#FF6F61", "#FFB400", "#26BFA6", "#4A90E2", "#9B6BFF", "#FF7BAC"
NAVY, CREAM, GHOST, INK, LINE = "#2A3350", "#FFF9F0", "#E9E2D6", "#3A3A3A", "#DCD3C4"
ACCENTS = [CORAL, MANGO, TEAL, SKY, GRAPE, BERRY]
PASTELS = ["#FFE3DE", "#FFF3C9", "#D9F4EF", "#DBE9FF", "#E9DFFF", "#FFE3EF"]

# ---------- kid words per letter ----------
WORDS = {
    "A": "apple", "B": "balloon", "C": "cat", "D": "dinosaur", "E": "elephant",
    "F": "fish", "G": "guitar", "H": "hat", "I": "ice cream", "J": "jellyfish",
    "K": "kite", "L": "lion", "M": "moon", "N": "nest", "O": "owl",
    "P": "penguin", "Q": "queen", "R": "rainbow", "S": "sun", "T": "tiger",
    "U": "umbrella", "V": "violin", "W": "whale", "X": "x-ray", "Y": "yo-yo",
    "Z": "zebra",
}

CSS = f"""
@font-face {{ font-family:'Inter'; src: url('{F_INTER}'); font-weight: 100 900; }}
@font-face {{ font-family:'Caveat'; src: url('{F_CAVEAT}'); font-weight: 400 700; }}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ font-family: 'Inter', sans-serif; color: {INK}; }}
.page {{ width: 210mm; height: 297mm; padding: 12mm 15mm; position: relative;
        overflow: hidden; background: #FFFFFF; page-break-after: always; }}
.page:last-child {{ page-break-after: auto; }}
.hand {{ font-family: 'Caveat', cursive; }}
.big {{ font-weight: 900; }}
.ghost {{ color: {GHOST}; }}
.center {{ text-align: center; }}
.small {{ font-size: 11.5pt; color: #6E675C; }}
.pgtitle {{ font-family:'Caveat', cursive; font-size: 30pt; color: {NAVY};
           text-align:center; margin-bottom: 4mm; font-weight: 700; }}
.pgtitle .sub {{ display:block; font-family:'Inter'; font-size: 10.5pt;
           font-weight: 400; color:#6E675C; margin-top:1.5mm; letter-spacing:.02em; }}
"""


def esc(s):
    return html.escape(s, quote=False)


def star_clip(color, size, letter, letter_color="#FFFFFF", fs_ratio=0.5, extra=""):
    """A star-shaped chip via clip-path with a centered letter."""
    return (f'<div class="star {extra}" style="width:{size}px;height:{size}px;'
            f'background:{color};clip-path:polygon(50% 0%,61% 35%,98% 35%,68% 57%,'
            f'79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%);'
            f'display:inline-flex;align-items:center;justify-content:center;">'
            f'<span style="color:{letter_color};font-weight:900;'
            f'font-size:{size*fs_ratio:.0f}px;line-height:1;">{esc(letter)}</span></div>')


def confetti(rng, n=26, alpha=0.9):
    """Absolute-positioned pastel shapes on the cover."""
    out = []
    for _ in range(n):
        kind = rng.random()
        x, y = rng.uniform(2, 93), rng.uniform(3, 95)
        s = rng.uniform(5, 15)
        col = rng.choice(PASTELS)
        if kind < 0.5:
            out.append(f'<div style="position:absolute;left:{x:.1f}%;top:{y:.1f}%;'
                       f'width:{s:.1f}mm;height:{s:.1f}mm;background:{col};'
                       f'border-radius:50%;opacity:{alpha};"></div>')
        else:
            out.append(f'<div style="position:absolute;left:{x:.1f}%;top:{y:.1f}%;'
                       f'width:{s:.1f}mm;height:{s:.1f}mm;background:{col};opacity:{alpha};'
                       f'transform:rotate({rng.uniform(0,90):.0f}deg);"></div>')
    return "".join(out)


def cover_page(name):
    up, tt = name.upper(), name.title()
    fs = min(150, int(560 / max(1, len(name) * 0.52)))
    return f"""
<div class="page" style="background:{CREAM};">
  {confetti(random.Random(f'conf-{name}'))}
  <div style="position:absolute;left:15mm;right:15mm;top:24mm;text-align:center;">
    <div class="hand" style="font-size:25pt;color:{CORAL};font-weight:700;">a personalised adventure for</div>
    <div style="font-size:{fs}px;font-weight:900;color:{NAVY};letter-spacing:.01em;
         line-height:1.12;margin-top:4mm;">{esc(up)}</div>
    <div style="height:3px;width:70mm;background:linear-gradient(90deg,{CORAL},{MANGO},{TEAL},{SKY},{GRAPE});margin:7mm auto;"></div>
    <div class="hand" style="font-size:31pt;color:{NAVY};font-weight:700;">My Name Adventure Book</div>
    <div class="small" style="margin-top:4mm;font-size:11pt;color:#6E675C;">letters · tracing · games · stories — made just for {esc(tt)}</div>
  </div>
  <div style="position:absolute;left:0;right:0;bottom:0;text-align:center;padding:9mm 15mm;">
    <div style="display:flex;justify-content:center;gap:4mm;">
      <div style="width:16mm;height:16mm;border-radius:50%;background:{CORAL};"></div>
      <div style="width:16mm;height:16mm;border-radius:50%;background:{MANGO};"></div>
      <div style="width:16mm;height:16mm;border-radius:50%;background:{TEAL};"></div>
      <div style="width:16mm;height:16mm;border-radius:50%;background:{SKY};"></div>
      <div style="width:16mm;height:16mm;border-radius:50%;background:{GRAPE};"></div>
    </div>
    <div class="small" style="margin-top:4mm;">Ages 3–6 &nbsp;·&nbsp; A4 · print at home &nbsp;·&nbsp; © QuietHue Designs</div>
  </div>
</div>"""


def belongs_page(name):
    tt = name.title()
    fs = min(140, int(540 / max(1, len(name) * 0.45)))
    return f"""
<div class="page" style="background:#FFFFFF;">
  <div class="pgtitle" style="font-size:34pt;margin-top:18mm;">This book belongs to</div>
  <div style="text-align:center;">
    <div class="hand" style="font-size:{fs}px;color:{CORAL};font-weight:700;line-height:1.15;">{esc(tt)}</div>
  </div>
  <div style="display:flex;justify-content:center;gap:3mm;margin-top:10mm;">
    {star_clip(MANGO, 40, '')}
  </div>
  <div style="margin:14mm auto 0;width:120mm;height:52mm;border:1.2mm dashed {LINE};border-radius:6mm;
       display:flex;align-items:center;justify-content:center;flex-direction:column;">
    <div class="hand" style="font-size:26pt;color:#B9B0A2;">this is me!</div>
    <div class="small">draw your picture inside the frame</div>
  </div>
  <div style="display:flex;justify-content:center;gap:18mm;margin-top:12mm;text-align:center;">
    <div><div class="small">I am</div><div style="border-bottom:1px solid {LINE};width:34mm;height:7mm;margin-top:2mm;"></div></div>
    <div><div class="small">My favourite colour</div><div style="display:flex;gap:2mm;margin-top:3.5mm;justify-content:center;">
       <div style="width:6mm;height:6mm;border-radius:50%;background:{CORAL};"></div>
       <div style="width:6mm;height:6mm;border-radius:50%;background:{MANGO};"></div>
       <div style="width:6mm;height:6mm;border-radius:50%;background:{TEAL};"></div>
       <div style="width:6mm;height:6mm;border-radius:50%;background:{SKY};"></div>
       <div style="width:6mm;height:6mm;border-radius:50%;background:{GRAPE};"></div>
       <div style="width:6mm;height:6mm;border-radius:50%;border:1px solid {LINE};"></div></div></div>
  </div>
</div>"""


def note_page(name):
    return f"""
<div class="page">
  <div class="pgtitle" style="font-size:30pt;">A note for grown-ups</div>
  <div style="margin:6mm auto 0;width:158mm;">
    <p style="font-size:12pt;line-height:1.7;color:#4A443C;">This book is {esc(name.title())}'s own name adventure.
    Young children learn to recognise and write their name long before they can read —
    it is usually the very first word they master. Work through the pages in any order, a
    little each day, and celebrate every page.</p>
    <div style="margin-top:8mm;">
      <div style="font-weight:800;color:{NAVY};margin-bottom:3mm;font-size:12.5pt;">What's inside</div>
      <div style="line-height:1.85;font-size:11.5pt;color:#4A443C;">
        • A letter banner to colour — one block for every letter of {esc(name.title())}'s name<br/>
        • Big trace letters, rainbow writing and a letter hunt<br/>
        • A sky full of stars spelling the name<br/>
        • One page per letter — trace the shape and learn a word<br/>
        • Four little stories starring {esc(name.title())} (read these aloud!)<br/>
        • A name maze and an official certificate at the end
      </div>
    </div>
    <div style="margin-top:8mm;">
      <div style="font-weight:800;color:{NAVY};margin-bottom:3mm;font-size:12.5pt;">Printing tips</div>
      <div style="line-height:1.85;font-size:11.5pt;color:#4A443C;">
        • Print on A4 paper at 100% (actual size), single or double sided<br/>
        • Ordinary pencils and crayons work on the light grey trace letters<br/>
        • Slide a page into a plastic sleeve and it becomes reusable with a whiteboard marker
      </div>
    </div>
    <div style="margin-top:10mm;border-top:1px solid {LINE};padding-top:5mm;color:#6E675C;font-size:10.5pt;">
      Every book is generated individually for the child's own name — ask for any name, any spelling.
    </div>
  </div>
</div>"""


def banner_page(name, rng):
    up = name.upper()
    n = len(up)
    size = max(34, min(96, int((640 - (n - 1) * 8) / n)))
    blocks = []
    for i, ch in enumerate(up):
        blocks.append(f'<div style="width:{size}px;height:{size}px;border-radius:{size*0.28:.0f}px;'
                      f'background:{ACCENTS[i % 6]};color:#fff;font-weight:900;font-size:{size*0.5:.0f}px;'
                      f'display:inline-flex;align-items:center;justify-content:center;">{ch}</div>')
    return f"""
<div class="page">
  <div class="pgtitle">My name is … <span class="sub">one block for every letter — colour them all in!</span></div>
  <div style="display:flex;justify-content:center;flex-wrap:wrap;gap:8px;margin-top:22mm;padding:0 4mm;">{''.join(blocks)}</div>
  <div class="center hand" style="font-size:30pt;color:#B9B0A2;margin-top:26mm;">{esc(name.title())}</div>
  <div class="center small" style="margin-top:2mm;">say it out loud, then spell it: {', '.join(up)}!</div>
</div>"""


def trace_big_page(name):
    up = name.upper()
    fs = min(120, int(600 / (len(name) * 0.72)))
    rows = [up, up]
    row_html = "".join(
        f'<div class="ghost big center" style="font-size:{fs}px;letter-spacing:.04em;'
        f'line-height:1.28;">{esc(row)}</div>' for row in rows)
    fs2 = min(72, int(620 / (len(name) * 0.55)))
    ghost2 = (f'<div class="hand ghost center" style="font-size:{fs2}px;line-height:1.5;">'
              f'{esc(name.title())}</div>')
    return f"""
<div class="page">
  <div class="pgtitle">Trace your name <span class="sub">start at the first letter — follow the grey shapes with your pencil</span></div>
  {row_html}
  <div class="center" style="margin-top:6mm;">
    <svg width="46" height="30" viewBox="0 0 46 30"><path d="M2 15 H34 M24 4 L40 15 L24 26" stroke="#FFB400" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
  </div>
  <div style="margin-top:14mm;">
    <div class="small center" style="margin-bottom:2mm;">now try it by yourself, right underneath:</div>
    {ghost2 * 2}
  </div>
</div>"""


def rainbow_page(name):
    colors = [CORAL, MANGO, "#7CB518", TEAL, SKY, GRAPE]
    labels = ["red", "orange", "green", "teal", "blue", "purple"]
    rows = []
    for i in range(6):
        rows.append(f'''
        <div style="display:flex;align-items:center;gap:8mm;margin:0 10mm;">
          <div style="width:14mm;text-align:right;color:#6E675C;font-size:10.5pt;">{i+1}.</div>
          <div style="width:10mm;height:10mm;border-radius:50%;border:1.2mm solid {colors[i]};"></div>
          <div style="width:6mm;color:#6E675C;font-size:10.5pt;">=</div>
          <div class="hand ghost" style="font-size:34pt;line-height:1.5;letter-spacing:.02em;flex:1;">{esc(name.title())}</div>
        </div>''')
    return f"""
<div class="page">
  <div class="pgtitle">Rainbow write <span class="sub">write your name six times — once with each crayon colour</span></div>
  <div style="margin-top:12mm;">{''.join(rows)}</div>
</div>"""


def letter_count_page(name):
    up = name.upper()
    size = max(40, min(84, int((620 - (len(up) - 1) * 6) / len(up))))
    blocks = "".join(
        f'<div style="width:{size}px;height:{size}px;border-radius:50%;'
        f'background:{ACCENTS[i % 6]};color:#fff;font-weight:900;font-size:{size*0.5:.0f}px;'
        f'display:inline-flex;align-items:center;justify-content:center;">{ch}</div>'
        for i, ch in enumerate(up))
    circles = "".join(
        f'<div style="width:15mm;height:15mm;border-radius:50%;border:1mm solid {ACCENTS[i % 6]};"></div>'
        for i in range(len(up)))
    return f"""
<div class="page">
  <div class="pgtitle">How many letters? <span class="sub">count the letters in your name</span></div>
  <div style="display:flex;justify-content:center;flex-wrap:wrap;gap:6px;margin-top:16mm;padding:0 4mm;">{blocks}</div>
  <div class="center" style="margin-top:16mm;">
    <span class="hand" style="font-size:28pt;color:{NAVY};">My name has </span>
    <span style="display:inline-flex;vertical-align:middle;margin:0 2mm;">{circles}</span>
    <span class="hand" style="font-size:28pt;color:{NAVY};"> letters!</span>
  </div>
  <div class="center small" style="margin-top:18mm;">colour one circle for every letter. {esc(up)} has {len(up)} letters — did you get it right?</div>
</div>"""


def letter_hunt_page(name, rng):
    """Grid 10x8. Each DISTINCT letter of the name appears exactly 3 times;
    filler letters are never name letters, so the declared counts are exact."""
    distinct = []
    for ch in name.upper():
        if ch not in distinct:
            distinct.append(ch)
    fillers = [c for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if c not in distinct]
    rng.shuffle(fillers)
    cells = [[""] * 10 for _ in range(8)]
    placed = 0
    pos = [(r, c) for r in range(8) for c in range(10)]
    rng.shuffle(pos)
    for ch in distinct:
        for _ in range(3):
            r, c = pos[placed]
            cells[r][c] = ch
            placed += 1
    fi = 0
    for r in range(8):
        for c in range(10):
            if cells[r][c] == "":
                cells[r][c] = fillers[fi % len(fillers)]
                fi += 1
    grid = "".join(
        f'<div style="width:56px;height:48px;display:inline-flex;align-items:center;justify-content:center;'
        f'font-size:24px;font-weight:700;color:{INK};">{ch}</div>'
        for row in cells for ch in row)
    legend = "".join(
        f'<div style="display:inline-flex;align-items:center;gap:2mm;margin:0 3mm;">'
        f'<div style="width:8mm;height:8mm;border-radius:50%;background:{ACCENTS[i % 6]};color:#fff;'
        f'font-weight:800;display:inline-flex;align-items:center;justify-content:center;font-size:11pt;">{ch}</div>'
        f'<span style="font-size:11.5pt;color:#4A443C;">find ×3</span></div>'
        for i, ch in enumerate(distinct))
    return f"""
<div class="page">
  <div class="pgtitle">Letter hunt <span class="sub">find every letter of your name and circle it</span></div>
  <div class="center" style="margin-top:4mm;line-height:2.1;">{legend}</div>
  <div style="width:560px;margin:6mm auto 0;line-height:0;">{grid}</div>
  <div class="center small" style="margin-top:6mm;">each letter of your name is hiding exactly 3 times. happy hunting, {esc(name.title())}!</div>
</div>"""


def stars_page(name):
    up = name.upper()
    n = len(up)
    size = max(46, min(86, int(540 / n)))
    stars = []
    for i, ch in enumerate(up):
        col = [MANGO, "#FFC94D"][i % 2]
        stars.append(star_clip(col, size + (i % 3) * 6 - 12, ch, "#FFFFFF", 0.5))
    fs2 = min(64, int(560 / (len(name) * 0.5)))
    return f"""
<div class="page" style="background:{NAVY};">
  <div style="position:absolute;top:14mm;right:18mm;width:26mm;height:26mm;border-radius:50%;background:{MANGO};"></div>
  <div style="position:absolute;top:16mm;right:16mm;width:26mm;height:26mm;border-radius:50%;background:{NAVY};"></div>
  <div style="position:absolute;top:8mm;left:12mm;">{star_clip("#9FB0E8", 18, "")}</div>
  <div style="position:absolute;top:38mm;left:26mm;">{star_clip("#9FB0E8", 13, "")}</div>
  <div style="position:absolute;top:52mm;right:34mm;">{star_clip("#9FB0E8", 16, "")}</div>
  <div class="pgtitle" style="color:#FFFFFF;margin-top:20mm;">Your name in the stars <span class="sub" style="color:#AEB9E8;">every star holds one letter of your name</span></div>
  <div style="text-align:center;margin-top:14mm;">{''.join(stars)}</div>
  <div style="text-align:center;margin-top:26mm;">
    <div class="hand ghost" style="font-size:{fs2}px;color:#B9C4EC;line-height:1.4;">{esc(name.title())}</div>
    <div style="color:#AEB9E8;font-size:11pt;margin-top:6mm;">trace your name with a white crayon… {esc(up)} shines bright!</div>
  </div>
</div>"""


def letter_pages(name, rng):
    """One page per distinct letter, two letters per page. Big ghost uppercase +
    lowercase to trace, plus a word starting with that letter."""
    distinct = []
    for ch in name.upper():
        if ch not in distinct:
            distinct.append(ch)
    pages = []
    for start in range(0, len(distinct), 2):
        chunk = distinct[start:start + 2]
        rows = []
        for j, ch in enumerate(chunk):
            accent = ACCENTS[(start // 2 + j) % 6]
            word = WORDS[ch]
            rows.append(f'''
            <div style="display:flex;align-items:center;gap:10mm;background:{PASTELS[(start // 2 + j) % 6]};
                 border-radius:8mm;padding:9mm 10mm;margin-top:6mm;">
              <div style="width:38mm;height:38mm;border-radius:50%;background:{accent};color:#fff;
                   font-weight:900;font-size:38pt;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;">{ch}</div>
              <div style="flex:1;">
                <div style="display:flex;align-items:center;gap:6mm;">
                  <div class="ghost big" style="font-size:64pt;line-height:1;">{ch}</div>
                  <div class="ghost" style="font-size:52pt;line-height:1;font-weight:400;">{ch.lower()}</div>
                </div>
                <div style="display:flex;gap:5mm;margin-top:3mm;">
                  <div class="ghost" style="font-size:30pt;line-height:1;">{ch.lower()}</div>
                  <div class="ghost" style="font-size:30pt;line-height:1;">{ch.lower()}</div>
                  <div class="ghost" style="font-size:30pt;line-height:1;">{ch.lower()}</div>
                </div>
              </div>
              <div style="text-align:center;flex:0 0 auto;">
                <div class="hand" style="font-size:24pt;color:{accent};font-weight:700;line-height:1;">{ch} is for</div>
                <div class="hand" style="font-size:30pt;color:{NAVY};font-weight:700;line-height:1.1;">{word}</div>
              </div>
            </div>''')
        pages.append(f'<div class="page"><div class="pgtitle">Letters in my name <span class="sub">trace the big letters — try the little ones too</span></div>{"".join(rows)}</div>')
    return pages


def write_myself_page(name):
    parts = []
    for r in range(4):
        midline = '<div style="position:absolute;top:11mm;left:0;right:0;border-top:1px dashed #D8D1C6;"></div>' if r else ""
        ghost = ""
        if r in (0, 1):
            ghost = ('<div class="hand ghost" style="position:absolute;left:50%;top:2px;'
                     'transform:translateX(-50%);font-size:52pt;line-height:1;">'
                     + esc(name.title()) + '</div>')
        parts.append(
            '<div style="position:relative;height:24mm;margin-top:2mm;">' + midline +
            '<div style="position:absolute;bottom:0;left:0;right:0;border-bottom:2px solid #8C857B;"></div>' +
            ghost + '</div>')
    return """
<div class="page">
  <div class="pgtitle">I can write it myself <span class="sub">trace the light name first — then write your name on the empty lines</span></div>
  <div style="margin:14mm 8mm 0;">""" + "".join(parts) + """</div>
</div>"""


# ---------- story pages ----------
ROCKET_SVG = """<svg viewBox="0 0 640 360" style="width:100%;">
 <circle cx="120" cy="80" r="26" fill="#FFD93D"/><circle cx="565" cy="90" r="8" fill="#9B6BFF"/>
 <circle cx="60" cy="230" r="6" fill="#FF7BAC"/><circle cx="590" cy="250" r="10" fill="#26BFA6"/>
 <circle cx="520" cy="60" r="5" fill="#4A90E2"/>
 <ellipse cx="320" cy="300" rx="230" ry="26" fill="#FFE3DE"/>
 <path d="M280 150 Q320 70 360 150 Z" fill="#FF6F61"/>
 <rect x="278" y="145" width="84" height="130" rx="18" fill="#FFFFFF" stroke="#FF6F61" stroke-width="6"/>
 <circle cx="320" cy="190" r="19" fill="#4A90E2"/>
 <path d="M278 220 L240 285 L278 285 Z" fill="#26BFA6"/>
 <path d="M362 220 L400 285 L362 285 Z" fill="#26BFA6"/>
 <path d="M300 275 L320 330 L340 275 Z" fill="#FFB400"/>
 <path d="M308 275 L320 305 L332 275 Z" fill="#FF6F61"/>
 <circle cx="330" cy="295" r="5" fill="#FFB400"/>
</svg>"""

MOON_SVG = """<svg viewBox="0 0 640 360" style="width:100%;">
 <rect width="640" height="360" rx="28" fill="#EAF4FF"/>
 <ellipse cx="320" cy="330" rx="250" ry="24" fill="#D9ECFA"/>
 <circle cx="150" cy="150" r="70" fill="#FFD93D"/>
 <circle cx="130" cy="135" r="12" fill="#F0B429"/><circle cx="165" cy="165" r="8" fill="#F0B429"/>
 <circle cx="150" cy="185" r="6" fill="#F0B429"/>
 <ellipse cx="430" cy="110" rx="55" ry="18" fill="#FFFFFF"/><ellipse cx="480" cy="95" rx="40" ry="13" fill="#FFFFFF"/>
 <ellipse cx="560" cy="170" rx="46" ry="15" fill="#FFFFFF"/>
 <circle cx="90" cy="70" r="5" fill="#9B6BFF"/><circle cx="520" cy="230" r="6" fill="#FF7BAC"/>
 <circle cx="600" cy="60" r="4" fill="#4A90E2"/><circle cx="250" cy="60" r="5" fill="#26BFA6"/>
 <circle cx="300" cy="260" r="16" fill="#FFB400"/><circle cx="460" cy="290" r="10" fill="#FF6F61"/>
</svg>"""

DINO_SVG = """<svg viewBox="0 0 640 360" style="width:100%;">
 <rect width="640" height="360" rx="28" fill="#E4F6E9"/>
 <circle cx="560" cy="80" r="34" fill="#FFD93D"/>
 <ellipse cx="320" cy="330" rx="260" ry="22" fill="#C9EAD4"/>
 <path d="M150 300 Q190 190 300 190 Q400 190 470 290 L430 300 Q360 215 300 215 Q230 215 185 300 Z" fill="#26BFA6"/>
 <circle cx="345" cy="205" r="34" fill="#26BFA6"/>
 <circle cx="355" cy="197" r="4.5" fill="#1F7A6B"/>
 <path d="M340 214 Q355 224 372 214" stroke="#1F7A6B" stroke-width="5" fill="none" stroke-linecap="round"/>
 <path d="M315 178 L325 150 L335 176 M350 168 L358 142 L367 167 M333 190 L343 162 L353 188" fill="#7CB518"/>
 <rect x="180" y="280" width="16" height="46" rx="8" fill="#26BFA6"/>
 <rect x="240" y="290" width="15" height="38" rx="7" fill="#26BFA6"/>
 <rect x="390" y="285" width="15" height="42" rx="7" fill="#26BFA6"/>
 <rect x="440" y="275" width="16" height="52" rx="8" fill="#26BFA6"/>
 <rect x="70" y="250" width="52" height="34" rx="6" fill="#A5723E" transform="rotate(-6 96 267)"/>
</svg>"""

BOAT_SVG = """<svg viewBox="0 0 640 360" style="width:100%;">
 <circle cx="120" cy="80" r="30" fill="#FFD93D"/>
 <path d="M70 90 L170 90 M90 74 L150 74 M110 58 L130 58" stroke="#FFB400" stroke-width="6" stroke-linecap="round"/>
 <rect x="0" y="150" width="640" height="210" rx="24" fill="#CDEAFA"/>
 <ellipse cx="140" cy="300" rx="90" ry="16" fill="#A8D8F5"/><ellipse cx="420" cy="330" rx="110" ry="18" fill="#A8D8F5"/>
 <path d="M180 240 L500 240 L450 310 L230 310 Z" fill="#FF6F61"/>
 <rect x="330" y="90" width="10" height="152" fill="#8C857B"/>
 <path d="M335 95 L335 225 L470 165 Z" fill="#FFFFFF" stroke="#FF7BAC" stroke-width="6" stroke-linejoin="round"/>
 <path d="M335 95 L335 225 L220 175 Z" fill="#FF7BAC"/>
 <rect x="330" y="72" width="16" height="16" fill="#26BFA6"/>
 <circle cx="560" cy="140" r="8" fill="#26BFA6"/><circle cx="90" cy="200" r="6" fill="#9B6BFF"/>
</svg>"""

CAKE_SVG = """<svg viewBox="0 0 640 360" style="width:100%;">
 <rect width="640" height="360" rx="28" fill="#FFF3E2"/>
 <circle cx="560" cy="70" r="34" fill="#FFD93D"/>
 <ellipse cx="320" cy="330" rx="240" ry="20" fill="#FFE3D2"/>
 <ellipse cx="320" cy="305" rx="160" ry="18" fill="#FFFFFF"/>
 <rect x="200" y="235" width="240" height="70" rx="12" fill="#FFB400"/>
 <rect x="230" y="170" width="180" height="65" rx="12" fill="#FF7BAC"/>
 <rect x="262" y="115" width="116" height="55" rx="12" fill="#FF6F61"/>
 <circle cx="300" cy="100" r="13" fill="#E63946"/><line x1="300" y1="87" x2="300" y2="72" stroke="#7CB518" stroke-width="5"/>
 <circle cx="200" cy="295" r="7" fill="#FF6F61"/><circle cx="420" cy="292" r="7" fill="#26BFA6"/>
 <circle cx="470" cy="245" r="6" fill="#9B6BFF"/><circle cx="170" cy="255" r="6" fill="#4A90E2"/>
 <circle cx="230" cy="200" r="6" fill="#FFD93D"/><circle cx="400" cy="195" r="6" fill="#26BFA6"/>
 <circle cx="310" cy="140" r="5" fill="#FFFFFF"/><circle cx="340" cy="150" r="5" fill="#FFFFFF"/>
</svg>"""

STORIES = [
    ("moon", "The Moon Ladder", MOON_SVG,
     "One night {n} put on stripey pyjamas and climbed a ladder of moonlight. Up, up, up — past the clouds, all the way to the silver moon. \u201cHello, Moon!\u201d said {n}. The moon smiled back, and they counted stars until {n}'s eyes felt very sleepy."),
    ("rocket", "The Cardboard Rocket", ROCKET_SVG,
     "{n} built a rocket out of a cardboard box, a colander helmet and very big dreams. 3\u2026 2\u2026 1\u2026 WHOOSH! {n} flew past Jupiter, waved at the Milky Way, and landed softly on a golden star. \u201cBest adventure ever,\u201d said {n}, and the star sparkled."),
    ("dino", "A Dinosaur at the Park", DINO_SVG,
     "One sunny day {n} went to the park and found a friendly dinosaur eating a sandwich. \u201cWould you like to play?\u201d asked the dinosaur. {n} nodded, so they played hide-and-seek behind the trees until the dinosaur had to go home for dinner."),
    ("boat", "The Great Bath Voyage", BOAT_SVG,
     "{n} set sail across the ocean \u2014 well, the bathtub \u2014 in a mighty cardboard ship. A whale splashed hello and a seagull waved. {n} steered past the island of towels and reached the far shore, where a fluffy towel-cape was waiting."),
]


def story_pages(name):
    tt = name.title()
    bgs = ["#EAF4FF", "#FFEFE2", "#E4F6E9", "#FFF3E2"]
    pages = []
    for i, (key, title, svg, text) in enumerate(STORIES):
        body = text.replace("{n}", tt)
        pages.append(f"""
<div class="page" style="background:{bgs[i]};">
  <div style="width:150mm;margin:2mm auto 0;">{svg}</div>
  <div style="width:152mm;margin:2mm auto 0;text-align:center;">
    <div class="hand" style="font-size:27pt;color:{NAVY};font-weight:700;">{esc(title)}</div>
    <p style="font-size:13.5pt;line-height:1.75;margin-top:4mm;color:#3F3A33;">{esc(body)}</p>
  </div>
  <div style="position:absolute;bottom:10mm;left:0;right:0;text-align:center;" class="small">{esc(tt)}'s story · page {i + 1} of 4</div>
</div>""")
    return pages


def maze_page(name, rng):
    """14x7 grid. A built-in serpentine path (42 cells) spells the name
    cyclically; fillers exclude name letters so the path is the ONLY place
    those letters appear. Start chip and finish star mark the ends."""
    up = name.upper()
    n = len(up)
    cols, rows = 14, 7
    # serpentine path through rows 1..5, cols 1..12
    path = []
    r = 1
    while r <= 5:
        col_range = range(1, 13) if r % 2 == 1 else range(12, 0, -1)
        for c in col_range:
            path.append((r, c))
        r += 1
    exclude = set(up)
    fillers = [c for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if c not in exclude]
    rng.shuffle(fillers)
    grid = [[""] * cols for _ in range(rows)]
    fi = 0
    for rr in range(rows):
        for cc in range(cols):
            if (rr, cc) not in path:
                grid[rr][cc] = fillers[fi % len(fillers)]
                fi += 1
    for i, (rr, cc) in enumerate(path):
        grid[rr][cc] = up[i % n]
    cell = 44
    rows_html = []
    for rr in range(rows):
        cells = []
        for cc in range(cols):
            ch = grid[rr][cc]
            is_start = (rr, cc) == path[0]
            is_end = (rr, cc) == path[-1]
            bg = "#FFF"
            if is_start:
                bg = "#7CB518"
            elif is_end:
                bg = MANGO
            cells.append(
                f'<div style="width:{cell}px;height:{cell}px;display:inline-flex;align-items:center;'
                f'justify-content:center;background:{bg};font-weight:800;font-size:19px;'
                f'color:{"#FFFFFF" if (is_start or is_end) else INK};">{ch}</div>')
        rows_html.append(f'<div style="line-height:0;">{"".join(cells)}</div>')
    seq_ok = "".join(grid[r][c] for r, c in path) == "".join(up[i % n] for i in range(len(path)))
    assert seq_ok, "maze path mismatch"
    return f"""
<div class="page">
  <div class="pgtitle">The {esc(up)} Maze <span class="sub">start at the green letter — follow your name all the way to the gold star</span></div>
  <div style="width:{cell * cols}px;margin:5mm auto 0;">{''.join(rows_html)}</div>
  <div class="center small" style="margin-top:7mm;">read each letter as you hop: {esc(" · ".join(up))} · {esc(" · ".join(up))} · {esc(" · ".join(up))} — then you are a maze master, {esc(name.title())}!</div>
</div>"""


def certificate_page(name):
    tt = name.title()
    return f"""
<div class="page" style="background:{CREAM};">
  <div style="position:absolute;inset:14mm;border:1.6mm solid {MANGO};border-radius:10mm;"></div>
  <div style="position:absolute;inset:17mm;border:0.5mm solid {MANGO};border-radius:8mm;"></div>
  <div style="position:absolute;left:0;right:0;top:34mm;text-align:center;">
    <div style="display:flex;align-items:center;justify-content:center;gap:7mm;">
      {star_clip(MANGO, 22, "")}
      <span style="color:{GRAPE};font-size:13pt;letter-spacing:.28em;font-weight:700;">CERTIFICATE OF AWESOMENESS</span>
      {star_clip(MANGO, 22, "")}
    </div>
    <div class="hand" style="font-size:22pt;color:#6E675C;margin-top:10mm;">this certifies that</div>
    <div style="font-size:44pt;font-weight:900;color:{CORAL};margin-top:2mm;">{esc(tt)}</div>
    <div style="color:#4A443C;font-size:12.5pt;margin-top:6mm;line-height:1.6;">is learning to write their name<br/>and is officially an awesome name explorer</div>
  </div>
  <div style="position:absolute;left:0;right:0;top:150mm;text-align:center;">
    {star_clip(MANGO, 70, "", "#FFFFFF", 0.4)}
  </div>
  <div style="position:absolute;left:24mm;right:24mm;bottom:30mm;display:flex;justify-content:space-between;">
    <div style="text-align:center;width:55mm;">
      <div style="border-bottom:1px solid #8C857B;height:16mm;"></div>
      <div class="small" style="margin-top:2mm;">date</div>
    </div>
    <div style="text-align:center;width:55mm;">
      <div class="hand" style="color:{TEAL};font-size:24pt;line-height:1.05;">The Name Book Team</div>
      <div class="small" style="margin-top:1mm;">signature</div>
    </div>
  </div>
</div>"""


def build_book(name, out_dir=None):
    """Generate + verify one book. Returns audit dict."""
    name = re.sub(r"[^A-Za-z]", "", name).strip()
    if not (2 <= len(name) <= 12):
        raise ValueError(f"name must be 2-12 letters, got {name!r}")
    tt = name.title()
    up = name.upper()
    rng = random.Random(f"kids-name-book::{tt}")
    rng2 = random.Random(f"kids-name-book2::{tt}")

    pages_html = []
    pages_html.append(cover_page(tt))
    pages_html.append(belongs_page(tt))
    pages_html.append(note_page(tt))
    pages_html.append(banner_page(tt, rng))
    pages_html.append(trace_big_page(tt))
    pages_html.append(rainbow_page(tt))
    pages_html.append(letter_count_page(tt))
    pages_html.append(letter_hunt_page(tt, rng))
    pages_html.append(stars_page(tt))
    pages_html.extend(letter_pages(tt, rng2))
    pages_html.append(write_myself_page(tt))
    pages_html.extend(story_pages(tt))
    pages_html.append(maze_page(tt, random.Random(f"kids-maze::{tt}")))
    pages_html.append(certificate_page(tt))

    doc = html_doc(CSS, "".join(pages_html))
    # Regression guard (added 2026-09-21): a literal backslash in the generated HTML means
    # an f-string leaked a repr - e.g. a list interpolated with {rows} instead of {"".join(rows)}.
    assert "\\" not in doc, "generated HTML contains a literal backslash - repr/list leak in an f-string?"
    slug = up.lower()
    out_dir = out_dir or OUT
    os.makedirs(out_dir, exist_ok=True)
    pdf_path = os.path.join(out_dir, f"My_Name_Adventure_Book_{tt}.pdf")
    render_pdf(doc, pdf_path, fmt="A4")
    html_md5 = hashlib.md5(doc.encode()).hexdigest()
    return {"name": tt, "upper": up, "pages": len(pages_html),
            "pdf": pdf_path, "html_md5": html_md5}


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    out_dir = None
    if "--out" in sys.argv:
        out_dir = sys.argv[sys.argv.index("--out") + 1]
    names = args or ["Oliver", "Charlotte", "Amelia"]
    from pypdf import PdfReader
    for nm in names:
        aud = build_book(nm, out_dir)
        r = PdfReader(aud["pdf"])
        box = r.pages[0].mediabox
        size_ok = abs(float(box.width) - 595.28) < 2 and abs(float(box.height) - 841.89) < 2
        txt = "".join((pg.extract_text() or "") for pg in r.pages)
        bs = txt.count(chr(92))
        assert bs == 0, f"{aud['name']}: PDF text layer has {bs} literal backslashes - text leak bug"
        assert "['" not in txt, f"{aud['name']}: PDF text layer has a list-repr fragment ['"
        print(f"{aud['name']}: pages_html={aud['pages']} pdf_pages={len(r.pages)} "
              f"A4={size_ok} size={os.path.getsize(aud['pdf'])}B md5={aud['html_md5'][:12]} leak_check=OK")
