"""Shared design system + render helpers for Idea Lab products."""
import os
import time

BASE = "/Users/hainguyen/idea_lab"
FONTS = os.path.join(BASE, "assets", "fonts")
ART = os.path.join(BASE, "artifacts")

F_INTER = f"file://{FONTS}/Inter.ttf"
F_PLAYFAIR = f"file://{FONTS}/Playfair.ttf"
F_CAVEAT = f"file://{FONTS}/Caveat.ttf"

C = dict(
    cream="#FAF7F2", paper="#FFFFFF", ink="#2A2A2A", muted="#6E6A63",
    accent="#B5673E", accent_dark="#8F4E2C", sage="#7A8B6F",
    line="#E8E1D6", soft="#F3EDE4",
)

FONT_FACES = f"""
@font-face {{ font-family:'Inter'; src: url('{F_INTER}'); font-weight: 100 900; }}
@font-face {{ font-family:'Playfair'; src: url('{F_PLAYFAIR}'); font-weight: 400 900; }}
@font-face {{ font-family:'Caveat'; src: url('{F_CAVEAT}'); font-weight: 400 700; }}
"""

BASE_CSS = FONT_FACES + """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Inter', sans-serif; color: #2A2A2A; }
.page { width: 210mm; min-height: 297mm; padding: 14mm 16mm; position: relative;
        background: #FFFFFF; }
.accent { color: #B5673E; } .sage { color: #7A8B6F; }
.hand { font-family: 'Caveat', cursive; }
.serif { font-family: 'Playfair', serif; }
.pagebreak { page-break-after: always; }
"""


def html_doc(css: str, body: str) -> str:
    return f"<!DOCTYPE html><html><head><meta charset='utf-8'><style>{BASE_CSS}{css}</style></head><body>{body}</body></html>"


def _playwright():
    from playwright.sync_api import sync_playwright
    return sync_playwright().start()


def render_pdf(html: str, out: str, fmt: str = "A4", landscape: bool = False,
               margin: str = "0", wait_ms: int = 400) -> str:
    pw = _playwright()
    try:
        browser = pw.chromium.launch()
        page = browser.new_page()
        page.set_content(html, wait_until="load")
        page.wait_for_timeout(wait_ms)
        page.pdf(path=out, format=fmt, landscape=landscape, print_background=True,
                 margin={"top": margin, "bottom": margin, "left": margin, "right": margin})
        browser.close()
    finally:
        pw.stop()
    return out


def shot(html: str, out: str, w: int = 2000, h: int = 1500, wait_ms: int = 600) -> str:
    pw = _playwright()
    try:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
        page.set_content(html, wait_until="load")
        page.wait_for_timeout(wait_ms)
        page.screenshot(path=out, clip={"x": 0, "y": 0, "width": w, "height": h})
        browser.close()
    finally:
        pw.stop()
    return out
